﻿近紅外光譜：醋酸定量與最佳光徑　全部章節
========================================

動畫課程（有旁白與小測驗）：https://tai-shengyeh.github.io/nir-pathlength-lesson/site/nir-pathlength/

這個教學包裡有：
  exercises/ch02_reference_design.R
  exercises/ch02_reference_design.ipynb
  exercises/ch02_reference_design_colab.ipynb
  exercises/ch03_wavelength_pitfall.R
  exercises/ch03_wavelength_pitfall.ipynb
  exercises/ch03_wavelength_pitfall_colab.ipynb
  exercises/ch04_pca_pls.R
  exercises/ch04_pca_pls.ipynb
  exercises/ch04_pca_pls_colab.ipynb
  exercises/orange/ch01_orange_guide.md
  exercises/orange/ch01_pathlength.ows
  exercises/orange/ch02_orange_guide.md
  exercises/orange/ch02_references.ows
  exercises/orange/ch03_orange_guide.md
  exercises/orange/ch03_wavelength_pitfall.ows
  exercises/orange/ch04_orange_guide.md
  exercises/orange/ch04_pca_pls.ows
  exercises/orange/img/ch01_orange_scatter.png
  exercises/orange/img/ch01_orange_selectcolumns.png
  exercises/orange/img/ch01_orange_spectra.png
  exercises/orange/img/ch01_orange_testscore.png
  exercises/orange/img/ch02_orange_formula.png
  exercises/orange/img/ch02_orange_scatter.png
  exercises/orange/img/ch02_orange_selectcolumns.png
  exercises/orange/img/ch02_orange_table.png
  exercises/orange/img/ch02_orange_testscore.png
  exercises/orange/img/ch03_orange_fss.png
  exercises/orange/img/ch03_orange_preprocess.png
  exercises/orange/img/ch03_orange_rank.png
  exercises/orange/img/ch03_orange_rank_shuffled.png
  exercises/orange/img/ch03_orange_testscore_inside.png
  exercises/orange/img/ch03_orange_testscore_outside.png
  exercises/orange/img/ch04_orange_pca.png
  exercises/orange/img/ch04_orange_pls.png
  exercises/orange/img/ch04_orange_preprocess.png
  exercises/orange/img/ch04_orange_scatter.png
  exercises/orange/img/ch04_orange_selectrows.png
  exercises/orange/img/ch04_orange_testscore.png
  exercises/pathlength_exercise.R
  exercises/pathlength_exercise.ipynb
  exercises/pathlength_exercise_colab.ipynb
  data/            光譜資料（所有練習共用）

怎麼開始：
1. 先看動畫課程，再做練習。
2. R：用 RStudio 開啟 exercises/ 裡的 .R 檔，按 Source；最後會列出自我驗證 PASS / FAIL。
3. Python：用 Jupyter 開啟 exercises/ 裡的 .ipynb（不是 _colab 那本），選「Run All」。
   或用 Google Colab：上傳 _colab.ipynb（資料已內嵌），選「執行階段 → 全部執行」。
4. Orange：先安裝 Orange Data Mining 與 Spectroscopy 外掛，開啟 exercises/orange/ 裡的 .ows 檔，
   照同資料夾的 _guide.md 操作（請保持資料夾結構，不要只拿出 .ows 檔）。

全部檢查都 PASS，才算完成。解壓縮時請保留資料夾結構。
