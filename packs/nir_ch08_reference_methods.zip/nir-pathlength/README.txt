﻿近紅外光譜：醋酸定量與最佳光徑　第 8 章　參考方法的誤差
========================================

動畫課程（有旁白與小測驗）：https://tai-shengyeh.github.io/nir-pathlength-lesson/site/nir-pathlength/ch08/

這個教學包裡有：
  exercises/ch08_reference_methods.R
  exercises/ch08_reference_methods.ipynb
  exercises/ch08_reference_methods_colab.ipynb
  exercises/ch08_titration_sheet.csv
  exercises/ch08_titration_sop.md
  exercises/orange/ch08_orange_guide.md
  exercises/orange/ch08_references.csv
  exercises/orange/ch08_references.ows
  exercises/orange/img/ch08_orange_gap.png
  exercises/orange/img/ch08_orange_scatter_atago.png
  exercises/orange/img/ch08_orange_scatter_pal30s.png
  exercises/orange/img/ch08_orange_scatter_titr.png
  exercises/orange/img/ch08_orange_slope_f097.png
  exercises/orange/img/ch08_orange_slope_titr.png
  exercises/orange/img/ch08_orange_table.png
  exercises/orange/img/ch08_orange_testscore.png
  data/            光譜資料（所有練習共用）

怎麼開始：
1. 先看動畫課程，再做練習。
2. R：用 RStudio 開啟 exercises/ 裡的 .R 檔，按 Source；最後會列出自我驗證 PASS / FAIL。
3. Python：用 Jupyter 開啟 exercises/ 裡的 .ipynb（不是 _colab 那本），選「Run All」。
   或用 Google Colab：上傳 _colab.ipynb（資料已內嵌），選「執行階段 → 全部執行」。
4. Orange：先安裝 Orange Data Mining 與 Spectroscopy 外掛，開啟 exercises/orange/ 裡的 .ows 檔，
   照同資料夾的 _guide.md 操作（請保持資料夾結構，不要只拿出 .ows 檔）。

全部檢查都 PASS，才算完成。解壓縮時請保留資料夾結構。
